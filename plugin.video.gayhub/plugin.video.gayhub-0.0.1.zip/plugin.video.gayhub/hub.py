import json
import sys
import urllib
import xbmcaddon
import xbmcgui
import xbmcplugin

thisPlugin = int(sys.argv[1])
addonId = "plugin.video.gayhub"
__addon__ = xbmcaddon.Addon(id=addonId)
dictallcats = dict()
caturl = "http://www.spankwire.com/api/HubTrafficApiCall?data=getCategoriesList&output=json&segment=gay"
catvidsurl = "http://www.spankwire.com/api/HubTrafficApiCall?data=searchVideos&output=json&thumbsize=small&count=100&segment=gay&search=&tags=&category={0}"
searchurl = "http://www.spankwire.com/api/HubTrafficApiCall?data=searchVideos&output=json&thumbsize=small&count=100&segment=gay&search={0}&tags=&category="


def readjson():
    f = file('spankwire.json', 'r')
    txt = f.read()
    f.close()
    dictallcats = json.JSONDecoder().decode(txt)
    clist = dictallcats.get('spankwire')
    # dictallcats = dict(spankwire=clist)
    return dictallcats


def url_for_category(catname='', sitename=''):
    sitedict = dictallcats.get(sitename)
    for entry in sitedict:
        if entry.get('label') == catname:
            return entry.get('path')


def addDirectoryItem(name, parameters={}, pic="DefaultFolder.png", lbl2=""):
    if lbl2 == "": lbl2 = name
    li = xbmcgui.ListItem(label=name, label2=lbl2, iconImage=pic, thumbnailImage=pic)
    url = sys.argv[0] + '?' + urllib.urlencode(parameters)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)


def make_viditems(itemlist):
    litems = []
    for item in itemlist:
        assert isinstance(item, dict)
        plugpath = item.get('path')
        name = item.get('label')
        sitename = plugpath.replace('http://', '').partition('/')[0].replace('www.', '').replace('.com', '').upper()
        litems.append(addDirectoryItem(name, parameters=dict(url=plugpath), lbl2=sitename))


def make_catitems(dictallcats):
    listofcats = dictallcats.get('spankwire')
    catvidslistitems = []
    for cat in listofcats:
        catname = cat.get('category')
        caturl = catvidsurl.format(catname)
        viditem = dict(label=catname, iconImage="DefaultFolder.png", thumbnailImage="DefaultFolder.png", path=caturl)
        catvidslistitems.append(viditem)
    return catvidslistitems


if __name__ == '__main__':
    allcats = dict()
    allcats = readjson()
    spankwirecats = []
    spankwirecats = allcats.get('spankwire')
    make_viditems(itemlist=spankwirecats)
    xbmcplugin.endOfDirectory(thisPlugin, True, True, False)

'''
params = parameters_string_to_dict(sys.argv[2])
name = str(params.get("name", ""))
url = str(params.get("url", ""))
url = urllib.unquote(url)
mode = str(params.get("mode", ""))
if not sys.argv[2]:
    ok = showContent()
else:
    if mode == str(1):
        ok = getVideos(name, url)
    elif mode == str(3):
        ok = getVideos2(name, url)
    elif mode == str(4):
        ok = getSearchQuery(name, url)
    elif mode == str(5):
        ok = getPage(name, url)  # getVideos3x
    elif mode == str(6):
        ok = getVideos4(name, url)
    elif mode == str(7):
        ok = getVideos5(name, url)

'''
