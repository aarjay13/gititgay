# xStream XBMC Addon (forked GAY gstream mods)
xStream is a xbmc plugin to watch streams from various german film, trailer, music and sport sites

* Modified g-stream.in to be gay only

## Available Sites:
* bundesliga.de `mainly working`
* burning-seri.es `mainly working`
* g-stream.in `mainly working`
* kinox.to `mainly working`
* movie4k.to `mainly working`

## Installation:
* Download [repository](http://xstream-addon.square7.ch/link_counter.php?url=http://xstream-addon.square7.ch/repo/repository.xstream/repository.xstream-1.0.3.zip) file
* Install it as a xbmc addon
* Install xstream addon from xstream repository

## Support
* Visit: http://xstream-addon.square7.ch
