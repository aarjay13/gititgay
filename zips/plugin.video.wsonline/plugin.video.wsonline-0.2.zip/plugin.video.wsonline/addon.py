from xbmcswift2 import Plugin, xbmc, ListItem, download_page, clean_dict, SortMethod
import os.path as path
import re
import urllib
import urllib2



plugin = Plugin()
__addondir__ = xbmc.translatePath(plugin.addon.getAddonInfo('path'))
__resdir__ = path.join(__addondir__, 'resources')
__imgsearch__ = path.join(__resdir__, 'search.png')

@plugin.route('/')
def index():
    itemsearch = {'label': 'Search', 'path': plugin.url_for(search), 'icon': __imgsearch__,
                  'thumbnail': __imgsearch__}
    item = {'label': 'Latest Episodes',
        'icon': 'DefaultFolder.png',
        'path': plugin.url_for(latest)}
    litems = []
    litems.append(item)
    litems.append(itemsearch)
    return litems

@plugin.route('/latest')
def latest():
    url = 'http://watchseries-online.la/last-350-episodes'
    headers = {}
    headers.update({'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.71 Safari/537.36'})
    headers.update({'Accept': 'application/json,text/x-json,text/x-javascript,text/javascript,text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8;charset=utf-8'})
    headers.update({'Accept-Language': 'en-US,en;q=0.5'})
    req = urllib2.Request(url=url, data=None, headers=headers)
    html = str(urllib2.urlopen(req).read())
    matches = re.compile(ur'href="(http...watchseries-online.la.episode.+?[^"])".+?</span>(.+?[^<])</a>', re.DOTALL + re.S + re.U).findall(html)
    litems = []
    for eplink, epname in matches:
        epname = epname.replace('&#8211;', '-')
        spath = plugin.url_for(episode, name=epname, url=eplink)
        item = {'label' : epname, 'icon':'DefaultVideoFolder.png', 'path':spath}
        item.setdefault(item.keys()[0])
        litems.append(item)
    return litems

@plugin.route('/search')
def search():
    searchtxt = ''
    searchtxt = plugin.get_setting('lastsearch')
    searchtxt = plugin.keyboard(searchtxt, 'Search All Sites', False)
    searchquery = searchtxt.replace(' ', '+')
    plugin.set_setting(key='lastsearch', val=searchtxt)
    urlsearch = 'http://watchseries-online.la/?s={0}&search='.format(searchquery)
    headers = {}
    headers.update({'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.71 Safari/537.36'})
    headers.update({'Accept': 'application/json,text/x-json,text/x-javascript,text/javascript,text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8;charset=utf-8'})
    headers.update({'Accept-Language': 'en-US,en;q=0.5'})
    req = urllib2.Request(url=urlsearch, data=None, headers=headers)
    html = unicode(urllib2.urlopen(req).read())
    #html = unicode(download_page(urlsearch))
    htmlres = unicode(html.partition('<div class="ddmcc">')[2]).split('</div>',1)[0]
    matches = re.compile(ur'href="(http...watchseries-online.la.category.+?[^"])".+?[^>]>(.+?[^<])<.a>', re.DOTALL + re.S + re.U).findall(unicode(htmlres))
    litems = []
    for slink, sname in matches:
        itempath = plugin.url_for(category, name=sname, url=slink)
        item = {'label' : sname, 'icon' : 'DefaultFolder.png', 'thumbnail' : 'DefaultFolder.png', 'path' : itempath}
        item.setdefault(item.keys()[0])
        litems.append(item)
    return litems

@plugin.route('/category/<name>/<url>')
def category(name, url):
    headers = {}
    headers.update({'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.71 Safari/537.36'})
    headers.update({'Accept': 'application/json,text/x-json,text/x-javascript,text/javascript,text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8;charset=utf-8'})
    headers.update({'Accept-Language': 'en-US,en;q=0.5'})
    req = urllib2.Request(url=url, data=None, headers=headers)
    html = str(urllib2.urlopen(req).read())
    banner = None
    try:
        banner = str(html.split('id="banner_single"', 1)[0].rpartition('src="')[2].split('"',1)[0])
        if banner.startswith('/'): banner = 'http://watchseries-online.la' + banner
    except:
        pass
    if banner is None: banner = 'DefaultVideoFolder.png'
    matches = re.compile(ur"href='(http...watchseries-online.la.episode.+?[^'])'.+?</span>(.+?[^<])</a>", re.DOTALL + re.S + re.U).findall(html)
    litems =[]
    for eplink, epname in matches:
        epname = epname.replace('&#8211;', '-')
        epath = plugin.url_for(episode, name=epname, url=eplink)
        item = {'label' : epname, 'icon' : banner, 'thumbnail' : banner, 'path' : epath}
        item.setdefault(item.keys()[0])
        litems.append(item)
    return litems

@plugin.route('/episode/<name>/<url>')
def episode(name, url):
    headers = {}
    headers.update({'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.71 Safari/537.36'})
    headers.update({'Accept': 'application/json,text/x-json,text/x-javascript,text/javascript,text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8;charset=utf-8'})
    headers.update({'Accept-Language': 'en-US,en;q=0.5'})
    req = urllib2.Request(url=url, data=None, headers=headers)
    html = str(urllib2.urlopen(req).read())
    matches = re.compile(ur'href="(http...openload.co/.+?[^"])"',re.DOTALL+re.S+re.U).findall(html)
    litems = []
    for link in matches:
        item = {'label' : link.split('openload.co/', 1)[1], 'icon':'DefaultVideoFolder.png', 'thumbnail' : 'DefaultVideoFolder.png', 'path' : link, 'isplayable' : True}
        item.setdefault(item.keys()[0])
        litems.append(item)
    return litems

if __name__ == '__main__':
    plugin.run()
